﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using CloudAssignment.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Auth;
namespace CloudAssignment.Models.Repository
{
    public interface IBlobStorageRepositoryInterface
    {
        IEnumerable<BlobViewModel> GetBlobs();
        bool UploadBlob(HttpPostedFileBase blobFile);
    }
}