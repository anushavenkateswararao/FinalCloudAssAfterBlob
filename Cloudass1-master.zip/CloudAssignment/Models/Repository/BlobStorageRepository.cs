﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CloudAssignment.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Auth;
using System.IO;
namespace CloudAssignment.Models.Repository
{
    public class BlobStorageRepository:IBlobStorageRepositoryInterface
    {
        private StorageCredentials storageCredentialsx;
        private CloudStorageAccount cloudStorageAccountx;
        private CloudBlobClient cloudBlobClientx;
        private CloudBlobContainer cloudBlobContainerx;

        private string containerNamex = "employeeexpensescontainer";

        public BlobStorageRepository()
        {
            string accountNamex = "employeeexpenses";//you storage account name from azure access key
            string keyx = "IGyHTsi6i8CE6HrpUWI9hrucN/gNkLAzSXHYthpT+xvl0aCYlcEGz3MDxk3RFb1KfseLrl/m5Rd5U2NeCaWLdg==";//copy the key from azure storage account access keys
            storageCredentialsx = new StorageCredentials(accountNamex, keyx);
            cloudStorageAccountx = new CloudStorageAccount(storageCredentialsx, true);
            cloudBlobClientx = cloudStorageAccountx.CreateCloudBlobClient();
            cloudBlobContainerx = cloudBlobClientx.GetContainerReference(containerNamex);
        }

        public IEnumerable<BlobViewModel> GetBlobs()
        {
            var context = cloudBlobContainerx.ListBlobs().ToList();
            IEnumerable<BlobViewModel> vm = context.Select(x => new BlobViewModel
            {
                //BlobContainerName = x.Container.
                BlobContainerName = x.Container.Name,
                StorageUri = x.StorageUri.PrimaryUri.ToString(),
                PrimaryUri = x.StorageUri.PrimaryUri.ToString(),
                ActualFileName = x.Uri.AbsoluteUri.Substring(x.Uri.AbsoluteUri.LastIndexOf("/")+ 1),
                FileExtension = System.IO.Path.GetExtension(x.Uri.AbsoluteUri.Substring(x.Uri.AbsoluteUri.LastIndexOf("/") + 1))
            }).ToList();
            return vm;
        }

        public bool UploadBlob(HttpPostedFileBase blobFile)
        {
            if (blobFile == null)
            { return false; }
            cloudBlobContainerx = cloudBlobClientx.GetContainerReference(containerNamex);
            CloudBlockBlob blockBlob = cloudBlobContainerx.GetBlockBlobReference(blobFile.FileName);
            using (var fileStream = (blobFile.InputStream))
            {
                blockBlob.UploadFromStream(fileStream);
            }
            return true;

        }
    }
}