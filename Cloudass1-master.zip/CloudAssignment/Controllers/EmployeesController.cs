﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CloudAssignment.Models;

namespace CloudAssignment.Controllers
{
   
    public class EmployeesController : Controller
    {
       
        private EmployeeExpensesEntities3 db = new EmployeeExpensesEntities3();
        [Authorize(Roles = "Supervisor")]
        public ActionResult Index()
        {
            return View(db.Employees.ToList());
        }
        [Authorize(Roles = "Supervisor,Employee")]
        public ActionResult EmployeeIndex()
        {
            return View(db.Employees.ToList());
        }
        [Authorize(Roles = "Supervisor")]
        public ActionResult Details(string id = null)
        {
            
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }


        //  
        // GET: /CRUD/Edit/5  
        [Authorize(Roles = "Supervisor,Employee")]
        public ActionResult EmployeeEdit(int? id)
        {
            Session["id"] = id;
            //Employee st = (Employee)Session["user"];
            Employee employee = db.Employees.Find(id);
            Session["employeeId"] = Convert.ToInt32(Session["id"]);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        //  
        // POST: /CRUD/Edit/5  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EmployeeEdit(Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(employee).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("EmployeeIndex");
                }
                
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        Console.WriteLine("error");
                    }
                }
            }
            return View(employee);
        }


        //  
        // GET: /CRUD/Create  
        [Authorize(Roles = "Supervisor")]
        public ActionResult Create()
        {
            return View();
        }

        //  
        // POST: /CRUD/Create  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee);
        }
        [Authorize(Roles = "Supervisor")]
        public ActionResult Edit(string id = null)
        {
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

          
         //POST: /CRUD/Edit/5  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        //  
        // GET: /CRUD/Delete/5  

        //public ActionResult Delete(string id = null)
        //{
        //    Employee employee = db.Employees.Find(id);
        //    if (employee == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(employee);
        //}

        ////  
        //// POST: /CRUD/Delete/5  

        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(string id)
        //{
        //    Employee employee = db.Employees.Find(id);
        //    db.Employees.Remove(employee);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

       

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
