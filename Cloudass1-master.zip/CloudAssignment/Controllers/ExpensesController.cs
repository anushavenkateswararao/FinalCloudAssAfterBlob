﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CloudAssignment.Models;
using CloudAssignment.Models.Repository;

namespace CloudAssignment.Controllers
{
    public class ExpensesController : Controller
    {
        private EmployeeExpensesEntities3 db = new EmployeeExpensesEntities3();

        //public ActionResult BlobIndex()
        //{
        //    return View();
        //}

        // GET: Expenses
        [Authorize(Roles = "Employee")]
        public ActionResult Index()
        {
            return View(db.Expenses.ToList());
        }
        [Authorize(Roles = "Employee")]
        public ActionResult Details(int id)
        {
            //Expens expens = new Expens();
            //expens.EmployeeId = Convert.ToInt32(Session["employeeId"]);
            //db.Expenses.Find(x =>x.Equals(e));
            //Employee st = new Employee(Session["employeeId"]);
            Expens expens = db.Expenses.Find(id);
            if (expens == null)
            {
                return HttpNotFound();
            }
            return View(expens);
        }


        // GET: /CRUD/Create  
        [Authorize(Roles = "Employee")]
        public ActionResult Create(/*int employeeId*/)
        {
            //Expens emp = new Expens();
            //emp.EmployeeId = employeeId;
            return View();
        }

        //  
        // POST: /CRUD/Create  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Expens expens)
        {
            if (ModelState.IsValid)
            {
               
                db.Expenses.Add(expens);
                db.SaveChanges();
                Session["employeeId"] = expens.EmployeeId;
                Session["ReceiptNumber"] = expens.ReceiptNumber;
                return RedirectToAction("Index");
            }

            return View(expens);
        }


        // GET: /CRUD/Edit/5  
        [Authorize(Roles = "Employee")]
        public ActionResult Edit(int id)
        {
            //SingleOrDefault(m => m.RecId == id);
            //Expens expens = db.Expenses.SingleOrDefault(m => m.EmployeeId == id);
            Expens expens = db.Expenses.Find(id);
            //employee can edit these fields
            TempData["receiptsubmittedDate"] = expens.ReceiptSubmittedDate;
            TempData["employeeName"] = expens.EmployeeName;
            TempData["receiptAmount"] = expens.ReceiptAmount;
            //employee can not edit these two feilds
            TempData["status"] = expens.Status;
            TempData["approvedDate"] = expens.ApproveDate;

            if (expens == null)
            {
                return HttpNotFound();
            }
            return View(expens);
        }

        //  
        // POST: /CRUD/Edit/5  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(FormCollection form)
        {
            Expens expens = new Expens();
            expens.ReceiptSubmittedDate = Convert.ToDateTime(form["receiptsubmittedDate"]);
            expens.ReceiptNumber = Convert.ToInt32(form["receiptNumber"]);
            //expens.EmployeeId = Convert.ToInt32(form["employeeId"]);
            expens.EmployeeName = form["employeeName"].ToString();
            expens.ReceiptAmount = Convert.ToInt32(form["receiptAmount"]);
            //status and amount can not edit by employee
            expens.Status = TempData["status"].ToString();
            expens.ApproveDate = Convert.ToDateTime(TempData["approvedDate"]);
            if (ModelState.IsValid)
            {
                db.Entry(expens).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(expens);
        }


        [Authorize(Roles = "Supervisor")]
        public ActionResult SuperviorIndex()
        {
            return View(db.Expenses.ToList());
        }
        [Authorize(Roles = "Supervisor")]
        public ActionResult SupervisorDetails(int id)
        {

            Expens expens = db.Expenses.Find(id);
            if (expens == null)
            {
                return HttpNotFound();
            }
            return View(expens);
        }


        // GET: /CRUD/Create  

        public ActionResult SupervisorCreate()
        {
            return View();
        }

        //  
        // POST: /CRUD/Create  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SupervisorCreate(Expens expens)
        {
            if (ModelState.IsValid)
            {
                db.Expenses.Add(expens);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(expens);
        }


        // GET: /CRUD/Edit/5  
        [Authorize(Roles = "Supervisor")]
        public ActionResult SupervisorEdit(int id)
        {
            //SingleOrDefault(m => m.RecId == id);
            //Expens expens = db.Expenses.SingleOrDefault(m => m.EmployeeId == id);
            Expens expens = db.Expenses.Find(id);
            //supervisor can not edit these fields
            TempData["receiptsubmittedDate"] = expens.ReceiptSubmittedDate;
            TempData["receiptNumber"] = expens.ReceiptNumber;
            TempData["employeeId"] = expens.EmployeeId;
            TempData["employeeName"] = expens.EmployeeName;
            TempData["receiptAmount"] = expens.ReceiptAmount;
            //supervisor can edit these two feilds
            TempData["status"] = expens.Status;
            TempData["approvedDate"] = expens.ApproveDate;
            if (expens == null)
            {
                return HttpNotFound();
            }
            return View(expens);
        }

        //  
        // POST: /CRUD/Edit/5  

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SupervisorEdit(FormCollection form)
        {
            Expens expens = new Expens();
            //supervisor can edit theses two
            expens.Status = form["status"].ToString();
            expens.ApproveDate = Convert.ToDateTime(form["approvedDate"]);
            //supervisor can not edit theses
            expens.ReceiptSubmittedDate = Convert.ToDateTime(TempData["receiptsubmittedDate"]);
            expens.ReceiptNumber = Convert.ToInt32(TempData["receiptNumber"]);
            expens.EmployeeId = Convert.ToInt32(TempData["employeeId"]);
            expens.EmployeeName = TempData["employeeName"].ToString();
            expens.ReceiptAmount = Convert.ToInt32(TempData["receiptAmount"]);
            if (ModelState.IsValid)
            {
                db.Entry(expens).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(expens);
        }


        //GET: /CRUD/Delete/5  

        //public ActionResult Delete(string id = null)
        //{
        //    Expens expens = db.Expenses.Find(id);
        //    if (expens == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(expens);
        //}

        ////  
        //// POST: /CRUD/Delete/5  

        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(string id)
        //{
        //    Expens expens = db.Expenses.Find(id);
        //    db.Expenses.Remove(expens);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //public ActionResult AddImage()
        //{
        //    return View();
        //}
        //[HttpPost]
        //[Authorize(Roles = "Employee")]
        //public ActionResult AddImage(Expens image)
        //{
        //    string fileName = Path.GetFileNameWithoutExtension(image.UploadReceipt.FileName);
        //    string extension = Path.GetExtension(image.UploadReceipt.FileName);
        //    fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
        //    image.UploadReceipt = "C:\Users\apamarth\Desktop\Cloudass1-master\CloudAssignment\Models\Images" + fileName;
        //    fileName = Path.Combine(Server.MapPath("C:\Users\apamarth\Desktop\Cloudass1-master\CloudAssignment\Models\Images"), fileName);
        //    image.UploadReceipt.SaveAs(fileName);
        //    using (EmployeeExpensesEntities1 db = new EmployeeExpensesEntities1())
        //    {
        //        db.Expenses.Add(image);
        //        db.SaveChanges();
        //    }
        //    ModelState.Clear();
        //        return View();
        //}



        //blob storage

        private readonly IBlobStorageRepositoryInterface repo;
        public ExpensesController(IBlobStorageRepositoryInterface _repo)
        {
            this.repo = _repo;
        }
        // GET: Blob
        [Authorize(Roles = "Supervisor")]
        public ActionResult BlobIndex()
        {
            var blobVm = repo.GetBlobs();
            return View(blobVm);

        }
        [HttpGet]
        [Authorize(Roles = "Employee")]
        public ActionResult UploadBlob()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadBlob(HttpPostedFileBase uploadFileName)
        {
            
            try
            {
                bool isUploaded = repo.UploadBlob(uploadFileName);
                if (isUploaded == true)
                {
                    //return RedirectToRoute("BlobIndex");
                    return RedirectToAction("BlobIndex");
                }

            }

            catch (InvalidRegistrationException e)
            {
                Console.WriteLine("InvalidRegistrationException: {0}", e.Message);
            }
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}