﻿using System;
using System.Runtime.Serialization;

namespace CloudAssignment.Controllers
{
    [Serializable]
    internal class InvalidRegistrationException : Exception
    {
        public InvalidRegistrationException()
        {
        }

        public InvalidRegistrationException(string message) : base(message)
        {
        }

        public InvalidRegistrationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidRegistrationException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}