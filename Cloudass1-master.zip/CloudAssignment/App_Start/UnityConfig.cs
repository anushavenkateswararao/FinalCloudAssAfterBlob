using System;

using Unity;
using CloudAssignment.Models.Repository;
using Unity.Injection;
using CloudAssignment.Controllers;

namespace CloudAssignment
{
    /// <summary>
    /// Specifies the Unity configuration for the main container.
    /// </summary>
    public static class UnityConfig
    {
        #region Unity Container
        private static Lazy<IUnityContainer> container =
          new Lazy<IUnityContainer>(() =>
          {
              var container = new UnityContainer();
              RegisterTypes(container);
              return container;
          });

        /// <summary>
        /// Configured Unity Container.
        /// </summary>
        public static IUnityContainer Container => container.Value;
        #endregion

        /// <summary>
        /// Registers the type mappings with the Unity container.
        /// </summary>
        /// <param name="container">The unity container to configure.</param>
        /// <remarks>
        /// There is no need to register concrete types such as controllers or
        /// API controllers (unless you want to change the defaults), as Unity
        /// allows resolving a concrete type even if it was not previously
        /// registered.
        /// </remarks>

        //public interface IC { }

        //class C : IC
        //{
        //    public C(string str, D d) { }
        //}

        //class D
        //{
        //}

        //IUnityContainer container = new UnityContainer();

        //container.RegisterType<D>();
//container.RegisterType<IC, C>(new InjectionFactory(c => new C("str", c.Resolve<D>())));

//IC cc = container.Resolve<IC>();
        public static void RegisterTypes(IUnityContainer container)
        {
            //IUnityContainer container = new UnityContainer();
            //container.RegisterType<D>();
            //container.RegisterType<IBlobStorageRepositoryInterface, BlobStorageRepository>
            //    (new InjectionConstructor(c => new BlobStorageRepository("containerNamex",c.Resolve<D>())));
            //container.RegisterType<UmbracoAuthorizeAttribute>(new InjectionConstructor());
            //container.RegisterType < Name of Controller> (new InjectionConstructor());
            container.RegisterType<IBlobStorageRepositoryInterface, BlobStorageRepository>
            (new InjectionConstructor());
            container.RegisterType<AccountController>(new InjectionConstructor());
            //container.RegisterType<AccountController, IBlobStorageRepositoryInterface, BlobStorageRepository>(new InjectionConstructor());
        }

    }
}