﻿select * from AspNetUsers
select * from AspNetUserRoles
select * from AspNetRoles
